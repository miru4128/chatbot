from django.apps import AppConfig


class CattleChatConfig(AppConfig):
    name = "cattle_chat"
